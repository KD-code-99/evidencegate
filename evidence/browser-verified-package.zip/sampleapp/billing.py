def invoice_total(units, unit_price, shipping):
    return shipping + unit_price * units
